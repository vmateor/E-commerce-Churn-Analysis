## Dataset

* **Source:** [Kaggle — E-Commerce Customer Churn Dataset](https://www.kaggle.com/datasets/dhairyajeetsingh/ecommerce-customer-behavior-dataset)
* **Rows:** 50,000 customer-level records
* **Key fields:** Login frequency, session duration, cart abandonment rate, days since last purchase, lifetime value, customer service calls, email open rate, discount usage rate, membership years, and more

> Raw data is not included in this repository. Download it directly from the Kaggle link above.

