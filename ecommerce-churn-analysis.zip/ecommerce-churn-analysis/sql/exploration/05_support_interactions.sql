-- Q5: How do customer support interactions relate to loyalty?

-- Part A: Churn rate and LTV by support call volume
SELECT
    CASE
        WHEN eccd."Customer_Service_Calls"::numeric <= 2 THEN '1 - Low (0-2 Calls)'
        WHEN eccd."Customer_Service_Calls"::numeric > 2 AND eccd."Customer_Service_Calls"::numeric <= 5 THEN '2 - Medium (3-5 Calls)'
        WHEN eccd."Customer_Service_Calls"::numeric > 5 AND eccd."Customer_Service_Calls"::numeric <= 8 THEN '3 - High (6-8 Calls)'
        WHEN eccd."Customer_Service_Calls"::numeric > 8 AND eccd."Customer_Service_Calls"::numeric <= 11 THEN '4 - Very High (9-11 Calls)'
        ELSE '5 - Extreme (12+ Calls)'
    END AS support_tier,
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv,
    ROUND(AVG(eccd."Login_Frequency"::numeric), 1) AS avg_logins,
    ROUND(AVG(eccd."Returns_Rate"::numeric), 1) AS avg_returns_rate
FROM ecommerce_customer_churn_dataset eccd
WHERE eccd."Customer_Service_Calls" IS NOT NULL
GROUP BY support_tier
ORDER BY support_tier;


-- Part B: Churn rate and LTV by review activity
SELECT
    CASE
        WHEN eccd."Product_Reviews_Written"::numeric = 0 THEN '0 - No Reviews'
        WHEN eccd."Product_Reviews_Written"::numeric > 0 AND eccd."Product_Reviews_Written"::numeric <= 2 THEN '1 - Low (1-2 Reviews)'
        WHEN eccd."Product_Reviews_Written"::numeric > 2 AND eccd."Product_Reviews_Written"::numeric <= 5 THEN '2 - Medium (3-5 Reviews)'
        WHEN eccd."Product_Reviews_Written"::numeric > 5 AND eccd."Product_Reviews_Written"::numeric <= 8 THEN '3 - High (6-8 Reviews)'
        ELSE '4 - Very High (9+ Reviews)'
    END AS review_tier,
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv,
    ROUND(AVG(eccd."Social_Media_Engagement_Score"::numeric), 1) AS avg_social_engagement
FROM ecommerce_customer_churn_dataset eccd
WHERE eccd."Product_Reviews_Written" IS NOT NULL
GROUP BY review_tier
ORDER BY review_tier;


-- Part C: Combined risk matrix — support calls x email engagement
SELECT
    CASE
        WHEN eccd."Customer_Service_Calls"::numeric > 5
            AND eccd."Email_Open_Rate"::numeric < 20 THEN '1 - High Calls + Low Email'
        WHEN eccd."Customer_Service_Calls"::numeric > 5
            AND eccd."Email_Open_Rate"::numeric >= 20 THEN '2 - High Calls + High Email'
        WHEN eccd."Customer_Service_Calls"::numeric <= 5
            AND eccd."Email_Open_Rate"::numeric < 20 THEN '3 - Low Calls + Low Email'
        ELSE '4 - Low Calls + High Email'
    END AS risk_segment,
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv
FROM ecommerce_customer_churn_dataset eccd
WHERE eccd."Customer_Service_Calls" IS NOT NULL
AND eccd."Email_Open_Rate" IS NOT NULL
GROUP BY risk_segment
ORDER BY risk_segment;

-- Deep dive: Best vs worst risk segment profile
-- Comparing Low Calls + High Email vs High Calls + Low Email

SELECT
    CASE
        WHEN eccd."Customer_Service_Calls"::numeric > 5
            AND eccd."Email_Open_Rate"::numeric < 20 THEN '1 - High Calls + Low Email'
        WHEN eccd."Customer_Service_Calls"::numeric <= 5
            AND eccd."Email_Open_Rate"::numeric >= 20 THEN '4 - Low Calls + High Email'
    END AS risk_segment,
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,

    -- Demographics
    ROUND(AVG(eccd."Age"::numeric), 1) AS avg_age,

    -- Tenure
    ROUND(AVG(eccd."Membership_Years"::numeric), 1) AS avg_tenure,

    -- Purchase behavior
    ROUND(AVG(eccd."Total_Purchases"::numeric), 1) AS avg_purchases,
    ROUND(AVG(eccd."Average_Order_Value"::numeric), 2) AS avg_order_value,
    ROUND(AVG(eccd."Days_Since_Last_Purchase"::numeric), 1) AS avg_days_since_purchase,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv,

    -- Engagement
    ROUND(AVG(eccd."Login_Frequency"::numeric), 1) AS avg_logins,
    ROUND(AVG(eccd."Session_Duration_Avg"::numeric), 1) AS avg_session_duration,
    ROUND(AVG(eccd."Pages_Per_Session"::numeric), 1) AS avg_pages_per_session,
    ROUND(AVG(eccd."Mobile_App_Usage"::numeric), 1) AS avg_mobile_app_usage,
    ROUND(AVG(eccd."Social_Media_Engagement_Score"::numeric), 1) AS avg_social_score,

    -- Friction
    ROUND(AVG(eccd."Cart_Abandonment_Rate"::numeric), 1) AS avg_cart_abandonment,
    ROUND(AVG(eccd."Returns_Rate"::numeric), 1) AS avg_returns_rate,
    ROUND(AVG(eccd."Discount_Usage_Rate"::numeric), 1) AS avg_discount_usage,

    -- Financial
    ROUND(AVG(eccd."Credit_Balance"::numeric), 2) AS avg_credit_balance,
    ROUND(AVG(eccd."Payment_Method_Diversity"::numeric), 1) AS avg_payment_methods,

    -- Support & content
    ROUND(AVG(eccd."Wishlist_Items"::numeric), 1) AS avg_wishlist_items,
    ROUND(AVG(eccd."Product_Reviews_Written"::numeric), 1) AS avg_reviews

FROM ecommerce_customer_churn_dataset eccd
WHERE (
    (eccd."Customer_Service_Calls"::numeric > 5 AND eccd."Email_Open_Rate"::numeric < 20)
    OR
    (eccd."Customer_Service_Calls"::numeric <= 5 AND eccd."Email_Open_Rate"::numeric >= 20)
)
GROUP BY risk_segment
ORDER BY risk_segment;

-- Signup quarter distribution for both extreme risk segments
-- If evenly distributed across quarters, lifecycle stage theory holds

SELECT
    CASE
        WHEN eccd."Customer_Service_Calls"::numeric > 5
            AND eccd."Email_Open_Rate"::numeric < 20 THEN '1 - High Calls + Low Email'
        WHEN eccd."Customer_Service_Calls"::numeric <= 5
            AND eccd."Email_Open_Rate"::numeric >= 20 THEN '4 - Low Calls + High Email'
    END AS risk_segment,
    eccd."Signup_Quarter",
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,
    ROUND(AVG(eccd."Membership_Years"::numeric), 2) AS avg_tenure,
    ROUND(AVG(eccd."Customer_Service_Calls"::numeric), 1) AS avg_calls,
    ROUND(AVG(eccd."Email_Open_Rate"::numeric), 1) AS avg_email_open_rate
FROM ecommerce_customer_churn_dataset eccd
WHERE (
    (eccd."Customer_Service_Calls"::numeric > 5 AND eccd."Email_Open_Rate"::numeric < 20)
    OR
    (eccd."Customer_Service_Calls"::numeric <= 5 AND eccd."Email_Open_Rate"::numeric >= 20)
)
GROUP BY risk_segment, eccd."Signup_Quarter"
ORDER BY risk_segment, eccd."Signup_Quarter";

-- Low Calls + High Email population by country and city
-- Looking for geographic concentration of our best customer segment

SELECT
    eccd."Country",
    eccd."City",
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv,
    ROUND(AVG(eccd."Login_Frequency"::numeric), 1) AS avg_logins,
    ROUND(AVG(eccd."Email_Open_Rate"::numeric), 1) AS avg_email_open_rate,
    ROUND(AVG(eccd."Customer_Service_Calls"::numeric), 1) AS avg_calls,
    ROUND(AVG(eccd."Total_Purchases"::numeric), 1) AS avg_purchases
FROM ecommerce_customer_churn_dataset eccd
WHERE eccd."Customer_Service_Calls"::numeric <= 5
AND eccd."Email_Open_Rate"::numeric >= 20
GROUP BY eccd."Country", eccd."City"
HAVING COUNT(*) >= 50
ORDER BY customers DESC, avg_ltv DESC;