-- Q3: What do the most valuable customers have in common?

-- Part A: Profile by LTV tier
WITH ltv_tiers AS (	
    SELECT
        *,
        NTILE(5) OVER (ORDER BY eccd."Lifetime_Value"::numeric DESC) AS ltv_quintile
    FROM ecommerce_customer_churn_dataset eccd
    WHERE eccd."Lifetime_Value" IS NOT NULL
)
SELECT
    CASE
        WHEN ltv_quintile = 1 THEN '1 - Top 20%'
        WHEN ltv_quintile = 2 THEN '2 - Upper-Mid'
        WHEN ltv_quintile = 3 THEN '3 - Mid'
        ELSE '4 - Bottom 40%'
    END AS ltv_segment,
    COUNT(*) AS customer_count,
    ROUND(AVG("Lifetime_Value"::numeric), 2) AS avg_ltv,
    ROUND(AVG("Age"::numeric), 1) AS avg_age,
    ROUND(AVG("Membership_Years"::numeric), 1) AS avg_tenure_years,
    ROUND(AVG("Total_Purchases"::numeric), 1) AS avg_purchases,
    ROUND(AVG("Average_Order_Value"::numeric), 2) AS avg_order_value,
    ROUND(AVG("Login_Frequency"::numeric), 1) AS avg_logins,
    ROUND(AVG("Payment_Method_Diversity"::numeric), 1) AS avg_payment_methods,
    ROUND(AVG("Email_Open_Rate"::numeric), 1) AS avg_email_open_rate,
    ROUND(AVG("Product_Reviews_Written"::numeric), 1) AS avg_reviews,
    ROUND(AVG("Discount_Usage_Rate"::numeric), 1) AS avg_discount_rate,
    ROUND(AVG("Customer_Service_Calls"::numeric), 1) AS avg_support_calls,
    ROUND(AVG("Returns_Rate"::numeric), 1) AS avg_returns,
    ROUND(AVG("Social_Media_Engagement_Score"::numeric), 1) AS avg_social_score,
    ROUND(100.0 * SUM("Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct
FROM ltv_tiers
GROUP BY ltv_quintile
ORDER BY ltv_quintile;

-- Q3 Deep Dive: Why are top 20% customers churning at 38.3%?
-- Analyzing unused fields for the top LTV tier vs the rest

WITH ltv_tiers AS (
    SELECT
        *,
        NTILE(5) OVER (ORDER BY eccd."Lifetime_Value"::numeric DESC) AS ltv_quintile
    FROM ecommerce_customer_churn_dataset eccd
    WHERE eccd."Lifetime_Value" IS NOT NULL
)
SELECT
    CASE
        WHEN ltv_quintile = 1 THEN '1 - Top 20%'
        ELSE '2 - Rest'
    END AS ltv_group,
    COUNT(*) AS customer_count,
    ROUND(100.0 * SUM("Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,

    -- Fields not yet analyzed
    ROUND(AVG("Session_Duration_Avg"::numeric), 2) AS avg_session_duration,
    ROUND(AVG("Cart_Abandonment_Rate"::numeric), 2) AS avg_cart_abandonment,
    ROUND(AVG("Wishlist_Items"::numeric), 2) AS avg_wishlist_items,
    ROUND(AVG("Days_Since_Last_Purchase"::numeric), 2) AS avg_days_since_purchase,
    ROUND(AVG("Mobile_App_Usage"::numeric), 2) AS avg_mobile_app_usage,
    ROUND(AVG("Credit_Balance"::numeric), 2) AS avg_credit_balance,

    -- Gender and geography won't show in averages so we check separately below
    ROUND(AVG("Pages_Per_Session"::numeric), 2) AS avg_pages_per_session

FROM ltv_tiers
GROUP BY ltv_group
ORDER BY ltv_group;

-- Gender split within top 20% churned vs active
WITH ltv_tiers AS (
    SELECT
        *,
        NTILE(5) OVER (ORDER BY eccd."Lifetime_Value"::numeric DESC) AS ltv_quintile
    FROM ecommerce_customer_churn_dataset eccd
    WHERE eccd."Lifetime_Value" IS NOT NULL
)
SELECT
    eccd."Gender",
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv
FROM ltv_tiers eccd
WHERE ltv_quintile = 1
GROUP BY eccd."Gender"
ORDER BY churn_rate_pct DESC;

-- Country split within top 20% churned vs active
WITH ltv_tiers AS (
    SELECT
        *,
        NTILE(5) OVER (ORDER BY eccd."Lifetime_Value"::numeric DESC) AS ltv_quintile
    FROM ecommerce_customer_churn_dataset eccd
    WHERE eccd."Lifetime_Value" IS NOT NULL
)
SELECT
    eccd."Country",
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv
FROM ltv_tiers eccd
WHERE ltv_quintile = 1
GROUP BY eccd."Country"
ORDER BY churn_rate_pct DESC;

-- Signup quarter split within top 20%
-- Do certain acquisition cohorts churn more?
WITH ltv_tiers AS (
    SELECT
        *,
        NTILE(5) OVER (ORDER BY eccd."Lifetime_Value"::numeric DESC) AS ltv_quintile
    FROM ecommerce_customer_churn_dataset eccd
    WHERE eccd."Lifetime_Value" IS NOT NULL
)
SELECT
    eccd."Signup_Quarter",
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv,
    ROUND(AVG(eccd."Days_Since_Last_Purchase"::numeric), 1) AS avg_days_since_purchase
FROM ltv_tiers eccd
WHERE ltv_quintile = 1
GROUP BY eccd."Signup_Quarter"
ORDER BY churn_rate_pct DESC;

-- Part B: LTV and churn by signup cohort
SELECT
    eccd."Signup_Quarter",
    COUNT(*) AS cohort_size,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv,
    ROUND(AVG(eccd."Membership_Years"::numeric), 1) AS avg_tenure,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct
FROM ecommerce_customer_churn_dataset eccd
WHERE eccd."Signup_Quarter" IS NOT NULL
GROUP BY eccd."Signup_Quarter"
ORDER BY eccd."Signup_Quarter";


-- Part C: LTV and churn by country
SELECT
    eccd."Country",
    COUNT(*) AS customers,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct
FROM ecommerce_customer_churn_dataset eccd
WHERE eccd."Lifetime_Value" IS NOT NULL
GROUP BY eccd."Country"
ORDER BY avg_ltv DESC;