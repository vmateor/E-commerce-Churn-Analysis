-- Q1: Which customer behaviors signal that someone is about to leave?

-- Comparing engagement and friction metrics between churned and active customers

SELECT
    eccd."Churned",
    COUNT(*) AS customer_count,

    -- Engagement signals
    ROUND(AVG(eccd."Login_Frequency"::numeric), 2) AS avg_logins_per_month,
    ROUND(AVG(eccd."Session_Duration_Avg"::numeric), 2) AS avg_session_minutes,
    ROUND(AVG(eccd."Pages_Per_Session"::numeric), 2) AS avg_pages_per_session,
    ROUND(AVG(eccd."Email_Open_Rate"::numeric), 2) AS avg_email_open_rate,
    ROUND(AVG(eccd."Mobile_App_Usage"::numeric), 2) AS avg_mobile_app_usage,
    ROUND(AVG(eccd."Social_Media_Engagement_Score"::numeric), 2) AS avg_social_score,

    -- Friction signals
    ROUND(AVG(eccd."Cart_Abandonment_Rate"::numeric), 2) AS avg_cart_abandonment_rate,
    ROUND(AVG(eccd."Returns_Rate"::numeric), 2) AS avg_returns_rate,
    ROUND(AVG(eccd."Customer_Service_Calls"::numeric), 2) AS avg_support_calls,

    -- Purchase recency
    ROUND(AVG(eccd."Days_Since_Last_Purchase"::numeric), 2) AS avg_days_since_last_purchase

FROM ecommerce_customer_churn_dataset eccd
GROUP BY eccd."Churned"
ORDER BY eccd."Churned";