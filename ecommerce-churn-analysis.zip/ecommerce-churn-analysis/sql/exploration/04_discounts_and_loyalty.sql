-- Q4: Do promotions and discounts create loyalty or just temporary buyers?

-- Part A: Churn rate, LTV and order value by discount usage tier
SELECT
    CASE
        WHEN eccd."Discount_Usage_Rate"::numeric <= 20 THEN '1 - Low (<=20%)'
        WHEN eccd."Discount_Usage_Rate"::numeric > 20 AND eccd."Discount_Usage_Rate"::numeric <= 50 THEN '2 - Medium (21-50%)'
        WHEN eccd."Discount_Usage_Rate"::numeric > 50 AND eccd."Discount_Usage_Rate"::numeric <= 75 THEN '3 - High (51-75%)'
        ELSE '4 - Very High (>75%)'
    END AS discount_usage_tier,
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv,
    ROUND(AVG(eccd."Average_Order_Value"::numeric), 2) AS avg_order_value,
    ROUND(AVG(eccd."Total_Purchases"::numeric), 1) AS avg_purchases,
    ROUND(AVG(eccd."Membership_Years"::numeric), 1) AS avg_tenure_years,
    ROUND(AVG(eccd."Returns_Rate"::numeric), 1) AS avg_returns_rate
FROM ecommerce_customer_churn_dataset eccd
WHERE eccd."Discount_Usage_Rate" IS NOT NULL
GROUP BY discount_usage_tier
ORDER BY discount_usage_tier;


-- Part B: Gross spend vs LTV gap by discount usage tier
SELECT
    CASE
        WHEN eccd."Discount_Usage_Rate"::numeric <= 20 THEN '1 - Low (<=20%)'
        WHEN eccd."Discount_Usage_Rate"::numeric > 20 AND eccd."Discount_Usage_Rate"::numeric <= 50 THEN '2 - Medium (21-50%)'
        WHEN eccd."Discount_Usage_Rate"::numeric > 50 AND eccd."Discount_Usage_Rate"::numeric <= 75 THEN '3 - High (51-75%)'
        ELSE '4 - Very High (>75%)'
    END AS discount_usage_tier,
    ROUND(AVG(eccd."Total_Purchases"::numeric * eccd."Average_Order_Value"::numeric), 2) AS avg_gross_spend,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv,
    ROUND(AVG(eccd."Total_Purchases"::numeric * eccd."Average_Order_Value"::numeric)
        - AVG(eccd."Lifetime_Value"::numeric), 2) AS spend_vs_ltv_gap
FROM ecommerce_customer_churn_dataset eccd
WHERE eccd."Discount_Usage_Rate" IS NOT NULL
AND eccd."Total_Purchases" IS NOT NULL
AND eccd."Average_Order_Value" IS NOT NULL
AND eccd."Lifetime_Value" IS NOT NULL
GROUP BY discount_usage_tier
ORDER BY discount_usage_tier;