-- Q2: How does purchase recency and frequency relate to churn?

-- Part A: Churn rate by recency bucket

SELECT
    CASE
        WHEN eccd."Days_Since_Last_Purchase"::numeric <= 30 THEN '1 - 0-30 days'
        WHEN eccd."Days_Since_Last_Purchase"::numeric > 30 AND eccd."Days_Since_Last_Purchase"::numeric <= 60 THEN '2 - 31-60 days'
        WHEN eccd."Days_Since_Last_Purchase"::numeric > 60 AND eccd."Days_Since_Last_Purchase"::numeric <= 90 THEN '3 - 61-90 days'
        WHEN eccd."Days_Since_Last_Purchase"::numeric > 90 AND eccd."Days_Since_Last_Purchase"::numeric <= 180 THEN '4 - 91-180 days'
        ELSE '5 - 180+ days'
    END AS recency_bucket,
    COUNT(*) AS total_customers,
    SUM(eccd."Churned"::numeric) AS churned_count,
    ROUND(100 * SUM(eccd."Churned"::numeric) / COUNT(*), 1) AS churn_rate_pct,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv
FROM ecommerce_customer_churn_dataset eccd
WHERE eccd."Days_Since_Last_Purchase" IS NOT NULL
GROUP BY recency_bucket
ORDER BY recency_bucket;


-- Part B: LTV, purchases and order value by churn status

SELECT
    eccd."Churned",
    COUNT(*) AS customer_count,
    ROUND(AVG(eccd."Lifetime_Value"::numeric), 2) AS avg_ltv,
    ROUND(AVG(eccd."Total_Purchases"::numeric), 2) AS avg_total_purchases,
    ROUND(AVG(eccd."Average_Order_Value"::numeric), 2) AS avg_order_value,
    ROUND(AVG(eccd."Days_Since_Last_Purchase"::numeric), 2) AS avg_days_since_last_purchase
FROM ecommerce_customer_churn_dataset eccd
GROUP BY eccd."Churned"
ORDER BY eccd."Churned";