CREATE OR REPLACE VIEW vw_churn_master AS
SELECT
    *,

    -- RFM scores
    NTILE(5) OVER (ORDER BY eccd."Days_Since_Last_Purchase"::numeric DESC) AS r_score,
    NTILE(5) OVER (ORDER BY eccd."Total_Purchases"::numeric ASC) AS f_score,
    NTILE(5) OVER (ORDER BY eccd."Lifetime_Value"::numeric ASC) AS m_score,

    -- LTV quintile
    NTILE(5) OVER (ORDER BY eccd."Lifetime_Value"::numeric DESC) AS ltv_quintile,

    -- Segments
    CASE
        WHEN eccd."Discount_Usage_Rate"::numeric <= 20 THEN '1 - Low (<=20%)'
        WHEN eccd."Discount_Usage_Rate"::numeric > 20 AND eccd."Discount_Usage_Rate"::numeric <= 50 THEN '2 - Medium (21-50%)'
        WHEN eccd."Discount_Usage_Rate"::numeric > 50 AND eccd."Discount_Usage_Rate"::numeric <= 75 THEN '3 - High (51-75%)'
        ELSE '4 - Very High (>75%)'
    END AS discount_usage_tier,

    CASE
        WHEN eccd."Customer_Service_Calls"::numeric <= 2 THEN '1 - Low (0-2 Calls)'
        WHEN eccd."Customer_Service_Calls"::numeric > 2 AND eccd."Customer_Service_Calls"::numeric <= 5 THEN '2 - Medium (3-5 Calls)'
        WHEN eccd."Customer_Service_Calls"::numeric > 5 AND eccd."Customer_Service_Calls"::numeric <= 8 THEN '3 - High (6-8 Calls)'
        WHEN eccd."Customer_Service_Calls"::numeric > 8 AND eccd."Customer_Service_Calls"::numeric <= 11 THEN '4 - Very High (9-11 Calls)'
        ELSE '5 - Extreme (12+ Calls)'
    END AS support_tier,

    CASE
        WHEN eccd."Cart_Abandonment_Rate"::numeric <= 40 THEN '1 - Low (0-40%)'
        WHEN eccd."Cart_Abandonment_Rate"::numeric > 40 AND eccd."Cart_Abandonment_Rate"::numeric <= 60 THEN '2 - Medium (41-60%)'
        WHEN eccd."Cart_Abandonment_Rate"::numeric > 60 AND eccd."Cart_Abandonment_Rate"::numeric <= 80 THEN '3 - High (61-80%)'
        WHEN eccd."Cart_Abandonment_Rate"::numeric > 80 AND eccd."Cart_Abandonment_Rate"::numeric <= 100 THEN '4 - Very High (81-100%)'
        ELSE '5 - Outliers (>100%)'
    END AS cart_abandonment_tier,

    CASE
        WHEN eccd."Days_Since_Last_Purchase" IS NULL THEN 'Unknown'
    	WHEN eccd."Days_Since_Last_Purchase"::numeric <= 30 THEN '1 - 0-30 days'
    	WHEN eccd."Days_Since_Last_Purchase"::numeric > 30 AND eccd."Days_Since_Last_Purchase"::numeric <= 60 THEN '2 - 31-60 days'
    	WHEN eccd."Days_Since_Last_Purchase"::numeric > 60 AND eccd."Days_Since_Last_Purchase"::numeric <= 90 THEN '3 - 61-90 days'
    	WHEN eccd."Days_Since_Last_Purchase"::numeric > 90 AND eccd."Days_Since_Last_Purchase"::numeric <= 180 THEN '4 - 91-180 days'
    	ELSE '5 - 180+ days'
	END AS recency_bucket,

    CASE
        WHEN eccd."Login_Frequency"::numeric <= 5 THEN '1 - Low (<=5)'
        WHEN eccd."Login_Frequency"::numeric > 5 AND eccd."Login_Frequency"::numeric <= 15 THEN '2 - Medium (6-15)'
        ELSE '3 - High (>15)'
    END AS activity_tier,

    CASE
        WHEN eccd."Age"::numeric < 25 THEN '1 - 18-24'
        WHEN eccd."Age"::numeric >= 25 AND eccd."Age"::numeric < 35 THEN '2 - 25-34'
        WHEN eccd."Age"::numeric >= 35 AND eccd."Age"::numeric < 45 THEN '3 - 35-44'
        WHEN eccd."Age"::numeric >= 45 AND eccd."Age"::numeric < 55 THEN '4 - 45-54'
        ELSE '5 - 55+'
    END AS age_group,

    CASE
        WHEN eccd."Customer_Service_Calls"::numeric > 5
            AND eccd."Email_Open_Rate"::numeric < 20 THEN '1 - Low Email + High Calls'
        WHEN eccd."Customer_Service_Calls"::numeric > 5
            AND eccd."Email_Open_Rate"::numeric >= 20 THEN '2 - High Email + High Calls'
        WHEN eccd."Customer_Service_Calls"::numeric <= 5
            AND eccd."Email_Open_Rate"::numeric < 20 THEN '3 - Low Email + Low Calls'
        ELSE '4 - High Email + Low Calls'
    END AS risk_segment,

    CASE
        WHEN NTILE(5) OVER (ORDER BY eccd."Lifetime_Value"::numeric DESC) = 1 THEN '1 - Top 20%'
        WHEN NTILE(5) OVER (ORDER BY eccd."Lifetime_Value"::numeric DESC) = 2 THEN '2 - Upper-Mid'
        WHEN NTILE(5) OVER (ORDER BY eccd."Lifetime_Value"::numeric DESC) = 3 THEN '3 - Mid'
        ELSE '4 - Bottom 40%'
    END AS ltv_segment

FROM ecommerce_customer_churn_dataset eccd;